import React from 'react'
import Google_Review from '../components/Google_Review';

const page = async ({ title, des }) => {
  
  return (
    <Google_Review
      main_title={title}
      content={des}
      reviewlogos={[]}
      slider={[]}
    />
  );
};

export default page