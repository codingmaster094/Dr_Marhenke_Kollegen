import HomePage from "@/app/home/page";
export default function Home() {
  return (
      <HomePage />
  );
}
